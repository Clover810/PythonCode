import random #ランダムをインポート

#何個作るか確認
x = input("偽コードをいくつ作りますか？:")
X = int(x)

#コード作成
for i in range (X):
 f = open('/storage/4284-12F6/MySpace/File/iTunes_Dummy_Codes.txt', 'a', encoding='UTF-16')
 ID = random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')
 for i in range (15):
  ID += random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')
 datalist = [str(ID),'\n']
 f.writelines(datalist)
 f.close()
print(X,"個作り終わりました。")